document.addEventListener('DOMContentLoaded', () => {
    const notificationContainer = document.getElementById('notification-container');
    let notificationTimeout;
    let currentLang = 'en';
    let moduleScripts = [];
    let isServiceRunning = false;
    let settingsChanged = false;
    let cpuTraceInterval = null;
    let cpuHistory = [];
    let cpuFreqChangeHistory = [];
    const MAX_HISTORY_POINTS = 100;
    let currentOS = 'Unknown';
    let launcherWarningAccepted = false;

    const translations = {
        'lite_mode_info': { en: "Lite mode for stability, avoids changing system permissions.", id: "Mode lite untuk stabilitas, menghindari perubahan izin sistem.", ar: "الوضع الخفيف للاستقرار، يتجنب تغيير أذونات النظام." },
        'network_locker_info': { en: "Locks network to a preferred type during gaming.", id: "Mengunci jaringan ke tipe pilihan saat bermain game.", ar: "يقفل الشبكة على نوع مفضل أثناء اللعب." },
        'window_logging_info': { en: "Disabling window logging may slightly reduce CPU usage.", id: "Menonaktifkan log window dapat sedikit mengurangi penggunaan CPU.", ar: "قد يؤدي تعطيل تسجيل النوافذ إلى تقليل استخدام وحدة المعالجة المركزية بشكل طفيف." },
        'logcat_adjuster_info': { en: "Adjusts main logcat size while gaming to save resources.", id: "Menyesuaikan ukuran logcat utama saat bermain untuk menghemat sumber daya.", ar: "يضبط حجم logcat الرئيسي أثناء اللعب لتوفير الموارد." },
        'system_kill_info': { en: "Allow killing system packages. Expert use only (D.W.Y.O.R).", id: "Izinkan mematikan paket sistem. Hanya untuk ahli (D.W.Y.O.R).", ar: "السماح بقتل حزم النظام. للاستخدام الخبير فقط (على مسؤوليتك)." },
        'smart_power_saver_info': { en: "Enables power saver when screen is off to save battery.", id: "Mengaktifkan penghemat daya saat layar mati untuk menghemat baterai.", ar: "تمكين موفر الطاقة عند إيقاف تشغيل الشاشة لتوفير البطارية." },
        'gapps_limiter_info': { en: "Limits GApps background activity using battery saver.", id: "Membatasi aktivitas latar belakang GApps menggunakan penghemat baterai.", ar: "يحد من نشاط GApps في الخلفية باستخدام موفر البطارية." },
        'quick_launch_info': { en: "Preloads game APKs into RAM for faster launch.", id: "Memuat APK game ke RAM untuk peluncuran lebih cepat.", ar: "تحميل ملفات APK للعبة مسبقًا في ذاكرة الوصول العشوائي لتشغيل أسرع." },
        'allow_compaction_info': { en: "Compresses cached processes in RAM. (Requires Android 13+ & RAM Manager)", id: "Mengompres proses cache di RAM. (Memerlukan Android 13+ & Manajer RAM)", ar: "ضغط العمليات المخزنة مؤقتًا في ذاكرة الوصول العشوائي. (يتطلب Android 13+ ومدير ذاكرة الوصول العشوائي)" },
        'silent_trace_info': { en: "Disables miscellaneous/unused tracing to reduce CPU consumption for better gameplay.", id: "Menonaktifkan jejak lain-lain/yang tidak terpakai untuk mengurangi konsumsi CPU demi gameplay yang lebih baik.", ar: "يعطل التتبع المتنوع/غير المستخدم لتقليل استهلاك وحدة المعالجة المركزية لتحسين اللعب." },
        'doze_info': { en: "Reduces battery drain when idle.", id: "Mengurangi penggunaan baterai saat idle.", ar: "يقلل من استنزاف البطارية عند الخمول." },
        'swappy_delta_info': { en: "Runtime frame sync to adjust SurfaceFlinger offset.", id: "Sinkronisasi frame runtime untuk menyesuaikan offset SurfaceFlinger.", ar: "مزامنة الإطارات في وقت التشغيل لضبط إزاحة SurfaceFlinger." },
        'silent_log_info': { en: "Freezes Android's logcat to reduce system overhead.", id: "Membekukan logcat Android untuk mengurangi beban sistem.", ar: "يجمد logcat الخاص بنظام Android لتقليل الحمل على النظام." },
        'device_config_opt_info': { en: "Applies device-specific configuration optimizations.", id: "Menerapkan optimasi konfigurasi khusus perangkat.", ar: "يطبق تحسينات التكوين الخاصة بالجهاز." },
        'touch_info': { en: "Enhances touch screen responsiveness.", id: "Meningkatkan responsivitas layar sentuh.", ar: "يعزز استجابة شاشة اللمس." },
        'driver_info': { en: "Changes graphics driver for games. Reset to return to default.", id: "Mengubah driver grafis untuk game. Reset untuk kembali ke default.", ar: "يغير برنامج تشغيل الرسومات للألعاب. إعادة التعيين للعودة إلى الوضع الافتراضي." },
        'fstrim_info': { en: "Trims filesystems in all directories under / (root).", id: "Melakukan trim sistem file di semua direktori di bawah / (root).", ar: "يقوم بقص أنظمة الملفات في كافة الدلائل الموجودة تحت / (الجذر)." },
        'cpu_reducer_info': { en: "Reduces CPU usage by optimizing background tasks.", id: "Mengurangi penggunaan CPU dengan mengoptimalkan tugas latar belakang.", ar: "يقلل من استخدام وحدة المعالجة المركزية عن طريق تحسين المهام الخلفية." },
        'use_trim_memory_info': { en: "Aggressively manages RAM by setting memory trim factor.", id: "Mengelola RAM secara agresif dengan mengatur faktor trim memori.", ar: "يدير ذاكرة الوصول العشوائي بقوة عن طريق تعيين عامل تقليم الذاكرة." },
        'trim_memory_level_info': { en: "Simulates memory pressure to force apps to reduce RAM usage.", id: "Mensimulasikan tekanan memori untuk memaksa aplikasi mengurangi penggunaan RAM.", ar: "يحاكي ضغط الذاكرة لإجبار التطبيقات على تقليل استخدام ذاكرة الوصول العشوائي." },
        'allow_whitelist_info': { en: "Exempts whitelisted apps from being force-stopped by RAM manager.", id: "Mengecualikan aplikasi yang masuk daftar putih dari penghentian paksa oleh manajer RAM.", ar: "يعفي التطبيقات الموجودة في القائمة البيضاء من الإيقاف القسري بواسطة مدير ذاكرة الوصول العشوائي." },
        'target_frame_rate_info': { en: "Targets a specific frame rate for a smoother experience.", id: "Menargetkan frame rate tertentu untuk pengalaman yang lebih lancar.", ar: "يستهدف معدل إطارات محدد لتجربة أكثر سلاسة." },
        'egl_preloader_info': { en: "Preloads EGL graphics libraries for a smoother UI.", id: "Memuat pustaka grafis EGL untuk UI yang lebih halus.", ar: "يقوم بالتحميل المسبق لمكتبات رسومات EGL لواجهة مستخدم أكثر سلاسة." },
        'job_opt_info': { en: "Optimizes app background jobs by adjusting scheduling.", id: "Mengoptimalkan pekerjaan latar belakang aplikasi dengan menyesuaikan penjadwalan.", ar: "يحسن مهام التطبيقات الخلفية عن طريق ضبط الجدولة." },
        'ram_manager_info': { en: "Automatically clears memory from unused processes.", id: "Secara otomatis membersihkan memori dari proses yang tidak digunakan.", ar: "يقوم تلقائيًا بمسح الذاكرة من العمليات غير المستخدمة." },
        'ram_manager_name': { en: "RAM Manager", id: "Manajer RAM", ar: "مدير الذاكرة العشوائية" },
        'ram_manager_exec_delay_info': { en: "Delay before RAM Manager executes its cleanup cycle.", id: "Penundaan sebelum Manajer RAM menjalankan siklus pembersihan.", ar: "تأخير قبل أن يقوم مدير ذاكرة الوصول العشوائي بتنفيذ دورة التنظيف." },
        'ram_factor_info': { en: "Aggressive may kill multitasking apps. Safety is safer.", id: "Agresif dapat mematikan aplikasi multitasking. Safety lebih aman.", ar: "الوضع العدواني قد يقتل التطبيقات متعددة المهام. الأمان أكثر أمانًا." },
        'dnd_info': { en: "Enable Do Not Disturb while gaming.", id: "Aktifkan mode Jangan Ganggu saat bermain game.", ar: "تمكين وضع عدم الإزعاج أثناء اللعب." },
        'device_group_info': { en: "bbk: For Realme/Oppo/Vivo. ubbk: For all other devices.", id: "bbk: Untuk perangkat Realme/Oppo/Vivo. ubbk: Untuk semua perangkat lain.", ar: "bbk: لأجهزة Realme/Oppo/Vivo. ubbk: لجميع الأجهزة الأخرى." },
        'debug_info': { en: "Print detailed debugging logs to debug.log.", id: "Cetak log debug terperinci ke debug.log.", ar: "اطبع سجلات تصحيح الأخطاء التفصيلية في debug.log." },
        'swappy_api_debug_info': { en: "Print Swappy-Delta specific debugging logs.", id: "Cetak log debug khusus Swappy-Delta.", ar: "اطبع سجلات تصحيح الأخطاء الخاصة بـ Swappy-Delta." },
        'pararel_execution_conf_info': { en: "Execute custom scripts at different service events.", id: "Jalankan skrip kustom pada event layanan yang berbeda.", ar: "تنفيذ البرامج النصية المخصصة في أحداث الخدمة المختلفة." },
        'max_pararel_thread_info': { en: "Max number of custom scripts to run simultaneously (1-8).", id: "Jumlah maks skrip kustom untuk berjalan bersamaan (1-8).", ar: "الحد الأقصى لعدد البرامج النصية المخصصة للتشغيل في وقت واحد (1-8)." },
        'pararel_dir_perf_info': { en: "Script(s) to run when 'Performance' profile is activated.", id: "Skrip untuk dijalankan saat profil 'Performa' diaktifkan.", ar: "البرنامج (البرامج) النصية للتشغيل عند تنشيط ملف تعريف 'الأداء'." },
        'pararel_dir_close_info': { en: "Script(s) to run when 'Balanced' profile is activated.", id: "Skrip untuk dijalankan saat profil 'Seimbang' diaktifkan.", ar: "البرنامج (البرامج) النصية للتشغيل عند تنشيط ملف تعريف 'متوازن'." },
        'pararel_dir_startup_info': { en: "Script(s) to run when the service starts.", id: "Skrip untuk dijalankan saat layanan dimulai.", ar: "البرنامج (البرامج) النصية للتشغيل عند بدء تشغيل الخدمة." },
        'pararel_dir_closeup_info': { en: "Script(s) to run when the service is uninstalled.", id: "Skrip untuk dijalankan saat layanan dicopot.", ar: "البرنامج (البرامج) النصية للتشغيل عند إلغاء تثبيت الخدمة." },
        'preload_size_limit_info': { en: "Format: 0=nolimit, 512K, 256M, 1G.", id: "Format: 0=tanpa batas, 512K, 256M, 1G.", ar: "التنسيق: 0=بلا حدود، 512K، 256M، 1G." },
        'warning_ram_info': { en: "Triggers memory trim at this minimum RAM percentage.", id: "Memicu trim memori pada persentase RAM minimum ini.", ar: "يشغل تقليم الذاكرة عند هذه النسبة المئوية الدنيا لذاكرة الوصول العشوائي." },
        'critical_ram_info': { en: "Kills background apps at this minimum RAM percentage.", id: "Mematikan aplikasi latar belakang pada persentase RAM minimum ini.", ar: "يقتل تطبيقات الخلفية عند هذه النسبة المئوية الدنيا لذاكرة الوصول العشوائي." },
        'standby_info': { en: 'If enabled, the WebUI server will not shut down automatically.', id: 'Jika aktif, server WebUI tidak akan mati secara otomatis.', ar: 'إذا تم التمكين، فلن يتم إيقاف خادم الواجهة تلقائيًا.' },
        'shutdown_time_info': { en: 'Minutes of inactivity before server shuts down. (Disabled in Standby Mode)', id: 'Menit nonaktif sebelum server mati. (Nonaktif dalam Mode Standby)', ar: 'دقائق عدم النشاط قبل إيقاف تشغيل الخادم. (معطل في وضع الاستعداد)' },
        'speed_mode_info': { en: "Enable speed mode while gaming. Increases performance, high power consumption.", id: "Aktifkan mode kecepatan saat bermain. Meningkatkan performa, konsumsi daya tinggi.", ar: "تمكين وضع السرعة أثناء اللعب. يزيد الأداء، استهلاك طاقة عالي." },
        'templimit_info': { en: "Disable temperature limit for better performance. May increase temps.", id: "Nonaktifkan batas suhu untuk performa lebih baik. Dapat meningkatkan suhu.", ar: "تعطيل حد درجة الحرارة لأداء أفضل. قد يزيد من درجات الحرارة." },
        'game_adj_info': { en: "Enable game adjustment for a boosted gaming experience.", id: "Aktifkan penyesuaian game untuk pengalaman bermain yang ditingkatkan.", ar: "تمكين تعديل اللعبة لتجربة لعب معززة." },
        'bypass_temp_warn_info': { en: "Enable/disable high temperature warning for battery safety.", id: "Aktifkan/nonaktifkan peringatan suhu tinggi untuk keamanan baterai.", ar: "تمكين/تعطيل تحذير ارتفاع درجة الحرارة لسلامة البطارية." },
        'user_exp_info': { en: "Allow/disallow user experience features for a smoother UI.", id: "Izinkan/larang fitur pengalaman pengguna untuk UI yang lebih lancar.", ar: "السماح/عدم السماح بميزات تجربة المستخدم لواجهة مستخدم أكثر سلاسة." },
        'fos_hdr_disabler_info': { en: "Enable or disable user HDR format. Disable for performance, enable for quality.", id: "Aktifkan atau nonaktifkan format HDR pengguna. Nonaktifkan untuk performa, aktifkan untuk kualitas.", ar: "تمكين أو تعطيل تنسيق HDR للمستخدم. تعطيل للأداء، تمكين للجودة." },
        'fos_network_acc_info': { en: "Enable or disable Vivo accelerated data network.", id: "Aktifkan atau nonaktifkan jaringan data yang dipercepat Vivo.", ar: "تمكين أو تعطيل شبكة بيانات Vivo المسرّعة." },
        'perf_enabler_info': { en: "Enable performance mode while gaming. High battery consumption.", id: "Aktifkan mode performa saat bermain. Konsumsi baterai tinggi.", ar: "تمكين وضع الأداء أثناء اللعب. استهلاك بطارية عالي." },
        'disable_temp_protect': { en: 'Disable Temp Protect', id: 'Nonaktifkan Pelindung Suhu', ar: 'تعطيل حماية درجة الحرارة' },
        'temp_protect_info': { en: 'Disable temperature limit while opening game.', id: 'Nonaktifkan batas suhu saat membuka game.', ar: 'تعطيل حد درجة الحرارة أثناء فتح اللعبة.' },
        'dynamic_swap_info': { en: 'Temporarily increases ZRAM usage ratio when RAM is low.', id: 'Meningkatkan rasio penggunaan ZRAM untuk sementara waktu pada saat RAM rendah.', ar: 'يزيد مؤقتًا من نسبة استخدام ZRAM عندما تكون ذاكرة الوصول العشوائي منخفضة.' },
        'allowed_zram_used_info': { en: 'The percentage amount of ZRAM that will be used temporarily.', id: 'Jumlah persentase ZRAM yang akan digunakan sementara.', ar: 'مقدار النسبة المئوية من ZRAM التي سيتم استخدامها مؤقتًا.' },
        'icon_quality_info': { en: "increase or decrease icon reduce to free more ram on Launcher incrase to high detailed apps icon ( default is 100 )", id: "naikkan atau turunkan ikon kurangi untuk mengosongkan lebih banyak ram di Launcher naikkan ke ikon aplikasi yang sangat detail ( default adalah 100 )", ar: "زيادة أو تقليل الرمز لتقليل استهلاك ذاكرة الوصول العشوائي في المشغل، زيادة للحصول على أيقونات تطبيقات عالية التفصيل (الافتراضي هو 100)" },
        'icon_format_info': { en: "change the icon app format to decrase ram usage on default Launcher", id: "ubah format ikon aplikasi untuk mengurangi penggunaan ram pada Launcher default", ar: "تغيير تنسيق أيقونة التطبيق لتقليل استخدام ذاكرة الوصول العشوائي في المشغل الافتراضي" },
        'launcher_warning_text': { en: "Warning this feature are experimental don't settings if you beginner may cause bug or Icons are not rendered because the Launcher does not support them or Launcher failed and crashing", id: "Peringatan fitur ini bersifat eksperimental jangan diatur jika Anda pemula dapat menyebabkan bug atau Ikon tidak dirender karena Peluncur tidak mendukungnya atau Peluncur gagal dan mogok", ar: "تحذير: هذه الميزة تجريبية، لا تقم بتغيير الإعدادات إذا كنت مبتدئًا فقد يتسبب ذلك في حدوث أخطاء أو عدم عرض الأيقونات لأن المشغل لا يدعمها أو فشل المشغل وتعطله" },
        'launcher_warning_accept': { en: "I'm not a beginner", id: "Saya bukan pemula", ar: "أنا لست مبتدئًا" },
        'launcher_warning_nevermind': { en: 'Nevermind', id: 'Lupakan', ar: 'لا تهتم' },
        'warning_title': { en: 'Warning', id: 'Peringatan', ar: 'تحذير' },
        'launcher_settings': { en: 'Launcher Settings', id: 'Pengaturan Launcher', ar: 'إعدادات المشغل' },
        'icon_quality': { en: 'Icon Quality', id: 'Kualitas Ikon', ar: 'جودة الأيقونة' },
        'icon_format': { en: 'Icon Format', id: 'Format Ikon', ar: 'تنسيق الأيقونة' },
        'settings_saved': { en: 'Setting Saved', id: 'Pengaturan Disimpan', ar: 'تم حفظ الإعداد' },
        'home': { en: 'Home', id: 'Beranda', ar: 'الرئيسية' },
        'general': { en: 'General', id: 'Umum', ar: 'عام' },
        'settings': { en: 'Settings', id: 'Pengaturan', ar: 'الإعدادات' },
        'advanced': { en: 'Advanced', id: 'Lanjutan', ar: 'متقدم' },
        'developer': { en: 'Developer', id: 'Pengembang', ar: 'مطور' },
        'cpu_trace': { en: 'CPU Trace', id: 'Lacak CPU', ar: 'تتبع المعالج' },
        'os_tunning': { en: 'OS Tunning', id: 'Tuning OS', ar: 'ضبط نظام التشغيل' },
        'webui_settings': { en: 'WebUI Settings', id: 'Pengaturan WebUI', ar: 'إعدادات الواجهة' },
        'main_actions': { en: 'Main Actions', id: 'Aksi Utama', ar: 'الإجراءات الرئيسية' },
        'performance_ai_status': { en: 'Performance AI Status', id: 'Status Performance AI', ar: 'حالة Performance AI' },
        'service_status': { en: 'Service Status', id: 'Status Layanan', ar: 'حالة الخدمة' },
        'running_for': { en: 'Running for', id: 'Berjalan selama', ar: 'يعمل منذ' },
        'cpu_usage': { en: 'CPU Usage', id: 'Penggunaan CPU', ar: 'استخدام المعالج' },
        'system_cpu_load': { en: 'System CPU Load', id: 'Beban CPU Sistem', ar: 'عبء نظام المعالج' },
        'ram_usage': { en: 'RAM Usage', id: 'Penggunaan RAM', ar: 'استخدام الذاكرة' },
        'current_profile': { en: 'Current Profile', id: 'Profil Saat Ini', ar: 'الملف الحالي' },
        'refresh': { en: 'Refresh', id: 'Segarkan', ar: 'تحديث' },
        'install': { en: 'Install', id: 'Instal', ar: 'تثبيت' },
        'uninstall': { en: 'Uninstall', id: 'Copot', ar: 'إلغاء التثبيت' },
        'reload': { en: 'Reload', id: 'Muat Ulang', ar: 'إعادة تحميل' },
        'exit': { en: 'Exit', id: 'Keluar', ar: 'خروج' },
        'community_support': { en: 'Community & Support', id: 'Komunitas & Dukungan', ar: 'المجتمع والدعم' },
        'join_telegram': { en: 'Join Us on Telegram', id: 'Gabung di Telegram', ar: 'انضم إلينا على تيليجرام' },
        'support_me': { en: 'Support Me', id: 'Dukung Saya', ar: 'ادعمني' },
        'device_module_info': { en: 'Device & Module Info', id: 'Info Perangkat & Modul', ar: 'معلومات الجهاز والوحدة' },
        'module': { en: 'Module', id: 'Modul', ar: 'الوحدة' },
        'status': { en: 'Status', id: 'Status', ar: 'الحالة' },
        'plugins': { en: 'Plugins', id: 'Plugin', ar: 'الإضافات' },
        'credits': { en: 'Credits', id: 'Kredit', ar: 'الحقوق' },
        'webui_inspiration': { en: 'WebUI Inspiration', id: 'Inspirasi WebUI', ar: 'إلهام الواجهة' },
        'device': { en: 'Device', id: 'Perangkat', ar: 'الجهاز' },
        'processing': { en: 'Processing...', id: 'Memproses...', ar: 'جاري المعالجة...' },
        'realtime_monitoring': { en: 'Real-time Monitoring', id: 'Pemantauan Real-time', ar: 'مراقبة في الوقت الحقيقي' },
        'standby_mode': { en: 'Standby Mode', id: 'Mode Standby', ar: 'وضع الاستعداد' },
        'inactivity_shutdown_time': { en: 'Inactivity Shutdown Time (minutes)', id: 'Waktu Mati Otomatis (menit)', ar: 'وقت إيقاف التشغيل لعدم النشاط (دقائق)' },
        'warning_ram_perc': { en: 'Warning RAM % (5-70)', id: 'Peringatan RAM % (5-70)', ar: 'تحذير الذاكرة % (5-70)' },
        'critical_ram_perc': { en: 'Critical RAM % (5-70)', id: 'Kritis RAM % (5-70)', ar: 'حرج الذاكرة % (5-70)' },
        'save_ram_settings': { en: 'Save RAM Thresholds', id: 'Simpan Ambang RAM', ar: 'حفظ عتبات الذاكرة' },
        'lite_mode': { en: 'Lite Mode', id: 'Mode Lite', ar: 'الوضع الخفيف' },
        'doze': { en: 'Doze Optimization', id: 'Optimasi Doze', ar: 'تحسين Doze' },
        'device_config_opt': { en: 'Device Config Opt', id: 'Optimasi Konfig Perangkat', ar: 'تحسين تكوين الجهاز' },
        'silent_log': { en: 'Silent Log', id: 'Log Senyap', ar: 'سجل صامت' },
        'fstrim': { en: 'Filesystem Trim', id: 'Trim Sistem Berkas', ar: 'تقليم نظام الملفات' },
        'run_fstrim': { en: 'Run Fstrim', id: 'Jalankan Fstrim', ar: 'تشغيل Fstrim' },
        'touch': { en: 'Touch Enhancement', id: 'Peningkatan Sentuhan', ar: 'تحسين اللمس' },
        'high': { en: 'High', id: 'Tinggi', ar: 'عالي' },
        'medium': { en: 'Medium', id: 'Sedang', ar: 'متوسط' },
        'low': { en: 'Low', id: 'Rendah', ar: 'منخفض' },
        'apply': { en: 'Apply', id: 'Terapkan', ar: 'تطبيق' },
        'driver': { en: 'Driver Selection', id: 'Pemilihan Driver', ar: 'اختيار السائق' },
        'game': { en: 'Game', id: 'Game', ar: 'لعبة' },
        'pre-release': { en: 'Pre-release', id: 'Pra-rilis', ar: 'إصدار أولي' },
        'swappy_delta': { en: 'Swappy Delta', id: 'Swappy Delta', ar: 'Swappy Delta' },
        'start': { en: 'Start', id: 'Mulai', ar: 'ابدأ' },
        'start_advanced': { en: 'Start-Advanced', id: 'Mulai-Lanjutan', ar: 'بدء متقدم' },
        'stop': { en: 'Stop', id: 'Hentikan', ar: 'إيقاف' },
        'general_settings': { en: 'General Settings', id: 'Pengaturan Umum', ar: 'إعدادات عامة' },
        'just_in_time_mode': { en: 'Just-In-Time Mode', id: 'Mode Just-In-Time', ar: 'وضع Just-In-Time' },
        'cpu_reducer': { en: 'CPU Reducer', id: 'Pengurang CPU', ar: 'مخفض وحدة المعالجة المركزية' },
        'egl_preloader': { en: 'EGL Preloader', id: 'Pramuat EGL', ar: 'محمل EGL المسبق' },
        'io_adjustment': { en: 'I/O Adjustment', id: 'Penyesuaian I/O', ar: 'تعديل الإدخال/الإخراج' },
        'disable_window_logging': { en: 'Disable Window Logging', id: 'Nonaktifkan Log Window', ar: 'تعطيل تسجيل النوافذ' },
        'logcat_adjuster': { en: 'Logcat Adjustment', id: 'Penyesuaian Logcat', ar: 'تعديل Logcat' },
        'allow_kill_whitelist_apps': { en: "Allow Kill Whitelist Apps", id: "Izinkan Matikan Aplikasi Whitelist", ar: "السماح بقتل تطبيقات القائمة البيضاء" },
        'dnd_while_gaming': { en: 'DND While Gaming', id: 'DND Saat Bermain Game', ar: 'عدم الإزعاج أثناء اللعب' },
        'gapps_limiter': { en: 'Gapps Limiter (Android 13+)', id: 'Pembatas Gapps (Android 13+)', ar: 'محدد Gapps (Android 13+)' },
        'game_manager': { en: 'Game Manager', id: 'Manajer Game', ar: 'مدير الألعاب' },
        'pubg_config_enable': { en: 'PUBG Mobile Global Config', id: 'Konfig Global PUBG Mobile', ar: 'تكوين PUBG Mobile العالمي' },
        'advance_settings': { en: 'Advance Settings', id: 'Pengaturan Maju', ar: 'إعدادات متقدمة' },
        'network_locker': { en: 'Network Locker', id: 'Kunci Jaringan', ar: 'قفل الشبكة' },
        'preferred_network_type': { en: 'Preferred Network Type', id: 'Tipe Jaringan Pilihan', ar: 'نوع الشبكة المفضل' },
        'net_4g_only': { en: '4G Only', id: 'Hanya 4G', ar: '4G فقط' },
        'net_4g_5g': { en: '4G/5G', id: '4G/5G', ar: '4G/5G' },
        'swappy_delta_rt_mode': { en: 'Swappy-Delta RT Mode', id: 'Mode RT Swappy-Delta', ar: 'وضع Swappy-Delta RT' },
        'target_frame_rate': { en: 'Target Frame Rate', id: 'Target Frame Rate', ar: 'معدل الإطارات المستهدف' },
        'downscale': { en: "Downscale", id: "Downscale", ar: "تقليل الحجم" },
        'api_ram_settings': { en: 'API & RAM Settings', id: 'Pengaturan API & RAM', ar: 'إعدادات API و RAM' },
        'dynamic_swap': { en: 'Dynamic Swap (Android 14+)', id: 'Swap Dinamis (Android 14+)', ar: 'التبديل الديناميكي (أندرويد 14+)' },
        'allowed_zram_used': { en: 'Allowed ZRAM Used (5-40%)', id: 'Penggunaan ZRAM Diizinkan (5-40%)', ar: 'استخدام ZRAM المسموح به (5-40%)' },
        'ram_manager_exec_delay': { en: 'RAM Manager Exec Delay (1-120s)', id: 'Tunda Eksekusi Manajer RAM (1-120d)', ar: 'تأخير تنفيذ مدير RAM (1-120 ثانية)' },
        'ram_factor': { en: 'RAM Factor', id: 'Faktor RAM', ar: 'عامل RAM' },
        'use_trim_memory': { en: 'Use Trim Memory', id: 'Gunakan Trim Memory', ar: 'استخدام Trim Memory' },
        'trim_memory_level': { en: 'Trim Memory Level', id: 'Level Trim Memory', ar: 'مستوى Trim Memory' },
        'system_kill': { en: 'System Kill', id: 'System Kill', ar: 'قتل النظام' },
        'smart_power_saver': { en: 'Smart Power Saver', id: 'Penghemat Daya Cerdas', ar: 'موفر الطاقة الذكي' },
        'game_preloading': { en: 'Game Preloading', id: 'Pramuat Game', ar: 'التحميل المسبق للعبة' },
        'shader_preload_size': { en: 'Shader Preload Size', id: 'Ukuran Pramuat Shader', ar: 'حجم التحميل المسبق للتظليل' },
        'preload_warning': { en: 'Warning: adjust the size or may get rebooted by low ram flag / kernel panic', id: 'Peringatan: sesuaikan ukuran atau perangkat bisa restart karena flag RAM rendah / kernel panic', ar: 'تحذير: اضبط الحجم وإلا فقد يتم إعادة تشغيل الجهاز بسبب علامة انخفاض ذاكرة الوصول العشوائي / ذعر النواة' },
        'quick_launch': { en: 'Quick Launch', id: 'Luncur Cepat', ar: 'إطلاق سريع' },
        'allow_compaction': { en: 'Allow Compaction', id: 'Izinkan Kompaksi', ar: 'السماح بالضغط' },
        'silent_trace': { en: 'Silent Trace', id: 'Jejak Senyap', ar: 'تتبع صامت' },
        'display_settings': { en: 'Display Settings', id: 'Pengaturan Tampilan', ar: 'إعدادات العرض' },
        'bypass_dynamic_refresh_rate': { en: 'Bypass Dynamic Refresh Rate', id: 'Lewati Refresh Rate Dinamis', ar: 'تجاوز معدل التحديث الديناميكي' },
        'device_refresh_rate': { en: 'Device Refresh Rate', id: 'Refresh Rate Perangkat', ar: 'معدل تحديث الجهاز' },
        'device_group': { en: 'Device Group', id: 'Grup Perangkat', ar: 'مجموعة الأجهزة' },
        'render_settings': { en: 'Render Settings', id: 'Pengaturan Render', ar: 'إعدادات العرض' },
        'hw_renderer': { en: 'HW Renderer', id: 'Perender HW', ar: 'عارض الأجهزة' },
        'hw_backend_renderer': { en: 'HW Backend Renderer', id: 'Perender Backend HW', ar: 'عارض الخلفية للأجهزة' },
        'hw_composition': { en: 'HW Composition', id: 'Komposisi HW', ar: 'تكوين الأجهزة' },
        'smooth_gui': { en: 'Smooth GUI', id: 'GUI Halus', ar: 'واجهة مستخدم رسومية سلسة' },
        'dev_menu': { en: 'Dev Menu', id: 'Menu Dev', ar: 'قائمة المطورين' },
        'print_debugging_log': { en: 'Print Debugging Log', id: 'Cetak Log Debug', ar: 'طباعة سجل التصحيح' },
        'print_swappy_debug_log': { en: 'Print Swappy-Delta Debugging Log', id: 'Cetak Log Debug Swappy-Delta', ar: 'طباعة سجل تصحيح Swappy-Delta' },
        'parallel_execution': { en: 'Parallel Execution', id: 'Eksekusi Paralel', ar: 'تنفيذ متوازي' },
        'max_parallel_threads': { en: 'Max Parallel Threads', id: 'Thread Paralel Maks', ar: 'الحد الأقصى للخيوط المتوازية' },
        'parallel_dir_perf': { en: 'Parallel Dir (Performance)', id: 'Dir Paralel (Performa)', ar: 'الدليل المتوازي (الأداء)' },
        'parallel_dir_balanced': { en: 'Parallel Dir (Balanced)', id: 'Dir Paralel (Seimbang)', ar: 'الدليل المتوازي (متوازن)' },
        'parallel_dir_startup': { en: 'Parallel Dir (Startup)', id: 'Dir Paralel (Startup)', ar: 'الدليل المتوازي (بدء التشغيل)' },
        'parallel_dir_uninstall': { en: 'Parallel Dir (Uninstall)', id: 'Dir Paralel (Copot)', ar: 'الدليل المتوازي (إلغاء التثبيت)' },
        'average_load': { en: 'Average Load', id: 'Beban Rata-rata', ar: 'متوسط التحميل' },
        'top_processes': { en: 'Top Processes', id: 'Proses Teratas', ar: 'أهم العمليات' },
        'installation_successful': { en: 'Installation successful!', id: 'Instalasi berhasil!', ar: 'اكتمل التثبيت بنجاح!' },
        'installation_failed': { en: 'Installation failed', id: 'Instalasi gagal', ar: 'فشل التثبيت' },
        'reason': { en: 'Reason', id: 'Alasan', ar: 'السبب' },
        'speed_mode': { en: 'Enable Speed Mode', id: 'Aktifkan Mode Cepat', ar: 'تمكين وضع السرعة' },
        'disable_templimit': { en: 'Disable Temp Limit', id: 'Nonaktifkan Batas Suhu', ar: 'تعطيل حد درجة الحرارة' },
        'game_adjustment': { en: 'Game Adjustment', id: 'Penyesuaian Game', ar: 'تعديل اللعبة' },
        'bypass_temp_warn': { en: 'Bypass High Temp Warning', id: 'Lewati Peringatan Suhu Tinggi', ar: 'تجاوز تحذير ارتفاع درجة الحرارة' },
        'user_experience': { en: 'Enable User Experience', id: 'Aktifkan Pengalaman Pengguna', ar: 'تمكين تجربة المستخدم' },
        'fos_hdr_disabler': { en: 'Disable HDR Format', id: 'Nonaktifkan Format HDR', ar: 'تعطيل تنسيق HDR' },
        'fos_network_acc': { en: 'Enable Data Network Accelerate', id: 'Aktifkan Akselerasi Jaringan Data', ar: 'تمكين تسريع شبكة البيانات' },
        'perf_enabler': { en: 'Perf Enabler', id: 'Pengaktif Perf', ar: 'ممكن الأداء' },
        'no_os_settings': { en: 'No specific tunning available for your OS at the moment.', id: 'Tidak ada tuning khusus yang tersedia untuk OS Anda saat ini.', ar: 'لا يوجد ضبط محدد متاح لنظام التشغيل الخاص بك في الوقت الحالي.' },
        'server_unreachable': { en: 'Server unreachable. UI is disabled.', id: 'Server tidak terjangkau. UI dinonaktifkan.', ar: 'الخادم غير متاح. الواجهة معطلة.'},
        'status_refreshed': { en: 'Status refreshed', id: 'Status diperbarui', ar: 'تم تحديث الحالة' },
        'shutting_down': { en: 'Shutting down server...', id: 'Mematikan server...', ar: 'إيقاف تشغيل الخادم...' },
        'reloading': { en: 'Reloading...', id: 'Memuat ulang...', ar: 'إعادة التحميل...' },
        'shutdown_failed': { en: 'Failed to shut down server.', id: 'Gagal mematikan server.', ar: 'فشل إيقاف تشغيل الخادم.' },
        'operation_successful': { en: 'Operation Successful!', id: 'Operasi Berhasil!', ar: 'العملية ناجحة!' },
        'reload_required': { en: 'Setting saved. Press "Reload" on the home page to apply.', id: 'Pengaturan disimpan. Tekan "Muat Ulang" di beranda untuk menerapkan.', ar: 'تم حفظ الإعداد. اضغط على "إعادة تحميل" في الصفحة الرئيسية للتطبيق.' },
        'exit_confirmation_title': { en: 'Unapplied Changes', id: 'Perubahan Belum Diterapkan', ar: 'تغييرات لم يتم تطبيقها' },
        'exit_confirmation_body': { en: 'You have settings that require a reload. What would you like to do?', id: 'Anda memiliki pengaturan yang perlu dimuat ulang. Apa yang ingin Anda lakukan?', ar: 'لديك إعدادات تتطلب إعادة تحميل. ماذا تريد أن تفعل؟' },
        'reload_and_exit': { en: 'Reload & Exit', id: 'Muat Ulang & Keluar', ar: 'إعادة تحميل وخروج' },
        'exit_without_reload': { en: 'Exit Without Reloading', id: 'Keluar Tanpa Muat Ulang', ar: 'الخروج بدون إعادة تحميل' },
    };
    
    const statusElements = {
        serviceStatus: document.getElementById('service-status'),
        servicePid: document.getElementById('service-pid'),
        runningTime: document.getElementById('running-time'),
        cpuUsage: document.getElementById('cpu-usage'),
        systemCpuLoad: document.getElementById('system-cpu-load'),
        ramUsage: document.getElementById('ram-usage'),
        currentProfileMode: document.getElementById('current-profile-mode'),
    };
    const moduleInfoElements = {
        moduleName: document.getElementById('module-name'),
        moduleVersion: document.getElementById('module-version'),
        moduleDeveloper: document.getElementById('module-developer'),
        moduleStatus: document.getElementById('module-status'),
        modulePlugins: document.getElementById('module-plugins'),
        moduleCredits: document.getElementById('module-credits'),
    };
    const deviceInfoElements = {
        deviceBrand: document.getElementById('device-brand'),
        deviceName: document.getElementById('device-name'),
        deviceArchitecture: document.getElementById('device-architecture'),
        deviceOsName: document.getElementById('device-os-name'),
        deviceAndroidVersion: document.getElementById('device-android-version'),
        deviceSdkVersion: document.getElementById('device-sdk-version'),
        deviceKernelVersion: document.getElementById('device-kernel-version'),
    };
    const refreshButton = document.getElementById('refresh-button');
    const actionButtons = document.querySelectorAll('.action-button[data-command]');
    const exitButton = document.getElementById('exit-button');
    const shutdownLoader = document.getElementById('shutdown-loader');
    const hamburgerMenu = document.getElementById('hamburger-menu');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const navLinks = document.querySelectorAll('.nav-link');
    const tabContents = document.querySelectorAll('.tab-content');
    const themeToggle = document.getElementById('theme-toggle');
    const langSelectionBar = document.getElementById('lang-selection-bar');
    const langSelectedValue = document.getElementById('lang-selected-value');
    
    const cpuTraceToggle = document.getElementById('cpu-trace-toggle');
    const cpuTraceGrid = document.getElementById('cpu-trace-grid');
    const cpuGraphCanvas = document.getElementById('cpu-usage-graph');
    const cpuAvgLoad = document.getElementById('cpu-avg-load');
    const cpuTopProcessesContainer = document.getElementById('cpu-top-processes');

    const standbyToggle = document.getElementById('standby-toggle');
    const shutdownTimeItem = document.getElementById('shutdown-time-item');
    const warningRamInput = document.getElementById('warning_ram_perc-input');
    const criticalRamInput = document.getElementById('critical_ram_perc-input');
    const saveRamBtn = document.getElementById('save-ram-thresholds-btn');
    const allowCompactionContainer = document.getElementById('allow-compaction-container');

    const exitConfirmModal = document.getElementById('exit-confirm-modal');
    const exitConfirmReloadBtn = document.getElementById('exit-confirm-reload');
    const exitConfirmContinueBtn = document.getElementById('exit-confirm-continue');

    const launcherWarningModal = document.getElementById('launcher-warning-modal');
    const launcherWarningAcceptBtn = document.getElementById('launcher-warning-accept');
    const launcherWarningNevermindBtn = document.getElementById('launcher-warning-nevermind');

    function showNotification(message, type = 'success', duration = 4000) {
        if (notificationTimeout) clearTimeout(notificationTimeout);
        notificationContainer.innerHTML = message.replace(/\n/g, '<br>');
        notificationContainer.className = 'show';
        notificationContainer.classList.add(type);
        notificationTimeout = setTimeout(() => {
            notificationContainer.className = notificationContainer.className.replace('show', '');
        }, duration);
    }

    async function handleApiCall(url, options = {}, buttonElement = null) {
        if (buttonElement) {
            buttonElement.classList.add('loading');
            buttonElement.disabled = true;
        }
        try {
            const response = await fetch(url, options);
            if (url === '/api/exit' && response.ok) {
                document.body.classList.add('server-down');
                document.getElementById('shutdown-loader').style.display = 'flex';
                setTimeout(() => location.reload(), 1500);
                return;
            }
            const data = await response.json();
            if (!response.ok) {
                const error = new Error(data.message || 'API request failed with status ' + response.status);
                error.data = data;
                throw error;
            }
            if (data.status !== 'success') {
                const error = new Error(data.message || 'API operation reported failure');
                error.data = data;
                throw error;
            }
            return data;
        } catch (error) {
            if (error.name !== 'AbortError' && error instanceof TypeError) {
                showNotification(translations['server_unreachable']?.[currentLang] || 'Server unreachable. UI is disabled.', 'error');
                document.body.classList.add('server-down');
            }
            throw error;
        } finally {
            if (buttonElement) {
                buttonElement.classList.remove('loading');
                buttonElement.disabled = false;
            }
        }
    }

    async function saveSetting(file, key, value) {
        const url = '/api/save-setting';
        const options = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ file, key, value })
        };
        try {
            await handleApiCall(url, options);
            await loadAllSettings();
            
            const reloadRequiredKeys = ['smooth_GUI', 'hw_renderer', 'hw_backend_renderer', 'hw_composition', 'bypass_dynamic_refresh_rate', 'job_opt', 'pubg_config_enable'];
            if (isServiceRunning && reloadRequiredKeys.includes(key)) {
                showNotification(translations['reload_required'][currentLang] || 'Setting saved. Press "Reload" to apply.', 'info', 6000);
                settingsChanged = true;
            } else {
                showNotification(translations['settings_saved'][currentLang] || 'Setting Saved', 'success', 2000);
            }
        } catch (error) {
            console.error(`Failed to save setting ${key} in ${file}:`, error);
            showNotification(error.message, 'error');
            await loadAllSettings();
        }
    }

    function setLanguage(lang) {
        currentLang = lang;
        document.documentElement.lang = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

        document.querySelectorAll('[data-lang-key]').forEach(el => {
            const key = el.dataset.langKey;
            const translation = translations[key]?.[lang] || translations[key]?.['en'];
            if (translation) {
                const icon = el.querySelector('i');
                const existingText = el.childNodes.length > 1 ? el.childNodes[1] : null;

                if (icon && existingText && existingText.nodeType === Node.TEXT_NODE) {
                    existingText.nodeValue = ` ${translation}`;
                } else {
                    el.textContent = translation;
                    if(icon) el.prepend(icon, ' ');
                }
            }
        });
        
        const selectedOption = langSelectionBar.querySelector(`.option-button[data-lang="${lang}"]`);
        langSelectedValue.textContent = selectedOption ? selectedOption.textContent : lang.toUpperCase();
        localStorage.setItem('language', lang);
    }
    
    function setupLanguageSelection() {
        setupBarSelection(langSelectionBar, (button) => {
            const lang = button.dataset.lang;
            setLanguage(lang);
        });
    }

    function toggleSidebar() {
        document.body.classList.toggle('sidebar-open');
    }

    hamburgerMenu.addEventListener('click', toggleSidebar);
    overlay.addEventListener('click', toggleSidebar);

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = link.dataset.tab;

            if (tabId === 'launcher' && !launcherWarningAccepted) {
                launcherWarningModal.style.display = 'flex';
                return;
            }

            tabContents.forEach(tab => tab.classList.remove('active'));
            document.getElementById(`${tabId}-tab`).classList.add('active');

            navLinks.forEach(nav => nav.classList.remove('active'));
            if (!link.closest('.sidebar-theme-toggle')) {
                 link.classList.add('active');
            }
            
            toggleSidebar();
        });
    });

    launcherWarningAcceptBtn.addEventListener('click', () => {
        launcherWarningAccepted = true;
        launcherWarningModal.style.display = 'none';
        document.querySelector('.nav-link[data-tab="launcher"]').click();
    });

    launcherWarningNevermindBtn.addEventListener('click', () => {
        launcherWarningModal.style.display = 'none';
    });

    function applyTheme(isLight) {
        document.body.classList.toggle('light-theme', isLight);
        document.querySelector('.light-icon').classList.toggle('active', isLight);
        document.querySelector('.dark-icon').classList.toggle('active', !isLight);
        localStorage.setItem('theme', isLight ? 'light' : 'dark');
        if (cpuTraceToggle.checked) {
            drawCpuGraph();
        }
    }
    
    themeToggle.addEventListener('change', (e) => applyTheme(e.target.checked));
    
    function getCurveControlPoints(points) {
        const tension = 0.4; 
        const pts = points.map(p => p); 
        const res = [];

        for (let i = 1; i < pts.length - 2; i++) {
            const p0 = pts[i - 1];
            const p1 = pts[i];
            const p2 = pts[i + 1];
            const p3 = pts[i + 2];

            const d1 = Math.sqrt(Math.pow(p1.x - p0.x, 2) + Math.pow(p1.y - p0.y, 2));
            const d2 = Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
            const d3 = Math.sqrt(Math.pow(p3.x - p2.x, 2) + Math.pow(p3.y - p2.y, 2));

            const b1 = d1 / (d1 + d2);
            const b2 = d2 / (d2 + d3);

            const cm1 = {
                x: p2.x - (p3.x - p1.x) * b2,
                y: p2.y - (p3.y - p1.y) * b2
            };
            const cm2 = {
                x: p1.x + (p2.x - p0.x) * b1,
                y: p1.y + (p2.y - p0.y) * b1
            };

            res.push({
                x: p1.x + (cm2.x - p1.x) * tension,
                y: p1.y + (cm2.y - p1.y) * tension
            });
            res.push({
                x: p2.x + (cm1.x - p2.x) * tension,
                y: p2.y + (cm1.y - p2.y) * tension
            });
        }
        return res;
    }

    function drawCpuGraph() {
        const ctx = cpuGraphCanvas.getContext('2d');
        const width = cpuGraphCanvas.clientWidth;
        const height = cpuGraphCanvas.clientHeight;
        cpuGraphCanvas.width = width;
        cpuGraphCanvas.height = height;
        ctx.clearRect(0, 0, width, height);

        const isLightTheme = document.body.classList.contains('light-theme');
        const glowColor = isLightTheme ? 'rgba(0, 123, 255, 0.7)' : 'rgba(52, 152, 219, 0.7)';
        const gradTop = isLightTheme ? 'rgba(120, 180, 255, 0.5)' : 'rgba(128, 90, 200, 0.5)';
        const gradBottom = isLightTheme ? 'rgba(0, 123, 255, 0.1)' : 'rgba(52, 152, 219, 0.2)';
        
        if (cpuHistory.length < 4) return;
        
        const step = width / (MAX_HISTORY_POINTS - 1);
        const graphPoints = cpuHistory.map((val, i) => ({
            x: i * step,
            y: height - (val / 100) * height
        }));

        const controlPoints = getCurveControlPoints(graphPoints);
        
        const path = new Path2D();
        path.moveTo(graphPoints[0].x, graphPoints[0].y);
        path.lineTo(graphPoints[1].x, graphPoints[1].y);
        for (let i = 1, j = 0; i < graphPoints.length - 2; i++, j += 2) {
            const p2 = graphPoints[i + 1];
            path.bezierCurveTo(controlPoints[j].x, controlPoints[j].y, controlPoints[j + 1].x, controlPoints[j + 1].y, p2.x, p2.y);
        }
        path.lineTo(graphPoints[graphPoints.length - 1].x, graphPoints[graphPoints.length - 1].y);
        
        const fillPath = new Path2D(path);
        fillPath.lineTo(width, height);
        fillPath.lineTo(0, height);
        fillPath.closePath();

        const gradient = ctx.createLinearGradient(0, 0, 0, height);
        gradient.addColorStop(0, gradTop);
        gradient.addColorStop(1, gradBottom);
        ctx.fillStyle = gradient;
        ctx.fill(fillPath);
        
        ctx.strokeStyle = glowColor;
        ctx.lineWidth = 2.5;
        ctx.shadowColor = glowColor;
        ctx.shadowBlur = 8;
        ctx.stroke(path);
        ctx.shadowBlur = 0;

        if (cpuFreqChangeHistory.length > 0) {
            const maxChanges = Math.max(...cpuFreqChangeHistory, 1);
            cpuFreqChangeHistory.forEach((val, i) => {
                if (val > 0) {
                    const x = i * step;
                    const intensity = Math.min(val / (maxChanges * 0.5), 1);
                    const r = 3 + intensity * 4;
                    
                    const glow = ctx.createRadialGradient(x, height - r, 0, x, height - r, r * 2);
                    glow.addColorStop(0, `rgba(0, 255, 255, ${0.4 * intensity})`);
                    glow.addColorStop(1, `rgba(0, 255, 255, 0)`);
                    ctx.fillStyle = glow;
                    ctx.fillRect(x - r * 2, height - r * 4, r * 4, r * 4);
                }
            });
        }
    }
    
    function renderTopProcesses(processes) {
        cpuTopProcessesContainer.innerHTML = '';
        if (processes && processes.length > 0) {
            processes.forEach(proc => {
                const item = document.createElement('div');
                item.className = 'process-item';
                item.innerHTML = `<span class="process-name">${proc.name}</span><span class="process-usage">${proc.usage}%</span>`;
                cpuTopProcessesContainer.appendChild(item);
            });
        }
    }

    function setupCpuTrace() {
        cpuTraceGrid.innerHTML = '';
        for (let i = 0; i < 8; i++) {
            const coreEl = document.createElement('div');
            coreEl.className = 'cpu-core-box';
            coreEl.id = `cpu-core-${i}`;
            coreEl.style.display = 'none';
            coreEl.innerHTML = `
                <div class="cpu-core-label">
                    <span>CPU ${i}</span>
                    <span class="cpu-core-temp" id="cpu-temp-${i}">--°C</span>
                </div>
                <div class="cpu-core-freq-bar-container">
                    <div class="cpu-core-freq-bar" id="cpu-freq-bar-${i}"></div>
                </div>
                <div class="cpu-core-stats">
                    <span class="cpu-core-freq" id="cpu-freq-${i}">0 MHz</span>
                    <span class="cpu-core-usage" id="cpu-usage-${i}">0%</span>
                </div>
            `;
            cpuTraceGrid.appendChild(coreEl);
        }

        cpuTraceToggle.addEventListener('change', () => {
            if (cpuTraceToggle.checked) {
                if (!cpuTraceInterval) {
                    fetchCpuData();
                    cpuTraceInterval = setInterval(fetchCpuData, 2000);
                }
            } else {
                if (cpuTraceInterval) {
                    clearInterval(cpuTraceInterval);
                    cpuTraceInterval = null;
                }
            }
        });
    }

    async function fetchCpuData() {
        try {
            const [cpuData, topData] = await Promise.all([
                handleApiCall('/api/cpu-trace'),
                handleApiCall('/api/top-processes')
            ]);

            if (cpuData && cpuData.status === 'success') {
                cpuAvgLoad.textContent = `${cpuData.avg_usage || 0}%`;
                cpuHistory.push(cpuData.avg_usage || 0);
                if (cpuHistory.length > MAX_HISTORY_POINTS) cpuHistory.shift();

                cpuFreqChangeHistory.push(cpuData.freq_changes_count || 0);
                if (cpuFreqChangeHistory.length > MAX_HISTORY_POINTS) cpuFreqChangeHistory.shift();

                drawCpuGraph();

                document.querySelectorAll('.cpu-core-box').forEach(el => el.style.display = 'none');
                cpuData.cpus.forEach(cpu => {
                    const coreEl = document.getElementById(`cpu-core-${cpu.core}`);
                    if (coreEl) {
                        coreEl.style.display = 'flex';
                        document.getElementById(`cpu-freq-${cpu.core}`).textContent = `${cpu.freq} MHz`;
                        document.getElementById(`cpu-temp-${cpu.core}`).textContent = cpu.temp !== 'N/A' ? `${cpu.temp}°C` : '--°C';
                        document.getElementById(`cpu-usage-${cpu.core}`).textContent = `${cpu.usage}%`;
                        const freqBar = document.getElementById(`cpu-freq-bar-${cpu.core}`);
                        if(freqBar) freqBar.style.width = `${cpu.usage}%`;
                    }
                });
            }

            if (topData && topData.status === 'success') {
                renderTopProcesses(topData.processes);
            }

        } catch (error) {
            console.error('Failed to fetch CPU data:', error);
            if(cpuTraceInterval) clearInterval(cpuTraceInterval);
            cpuTraceInterval = null;
            cpuTraceToggle.checked = false;
        }
    }

    function setupWebUISettings() {
        standbyToggle.addEventListener('change', (e) => {
            shutdownTimeItem.classList.toggle('disabled', e.target.checked);
        });
    }

    function setupRamThresholds() {
        saveRamBtn.addEventListener('click', async () => {
            const warningVal = parseInt(warningRamInput.value, 10);
            const criticalVal = parseInt(criticalRamInput.value, 10);

            if (isNaN(warningVal) || isNaN(criticalVal) || warningVal < 5 || warningVal > 70 || criticalVal < 5 || criticalVal > 70) {
                showNotification('Values must be between 5 and 70.', 'error');
                return;
            }
            
            if (warningVal <= criticalVal) {
                showNotification('Warning value must be greater than Critical value.', 'error');
                return;
            }

            try {
                await handleApiCall('/api/save-ram-thresholds', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `warning=${warningVal}&critical=${criticalVal}`
                }, saveRamBtn);
                showNotification('RAM thresholds saved.', 'success');
                await loadAllSettings();
            } catch (error) {
                console.error('Failed to save RAM thresholds:', error);
                showNotification(error.message, 'error');
                await loadAllSettings();
            }
        });
    }

    function setupBarSelection(barElement, onSelectCallback) {
        const optionButtons = barElement.querySelectorAll('.option-button');
        barElement.addEventListener('click', (e) => {
            if (barElement.closest('.disabled')) return;
            e.stopPropagation();
            document.querySelectorAll('.bar-selection.active').forEach(other => {
                if (other !== barElement) other.classList.remove('active');
            });
            barElement.classList.toggle('active');
        });
        optionButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                onSelectCallback(button);
                barElement.classList.remove('active');
            });
        });
    }

    document.addEventListener('click', (e) => {
        document.querySelectorAll('.bar-selection.active').forEach(bar => bar.classList.remove('active'));
        if (e.target.matches('.fa-info-circle')) {
            const infoKey = e.target.dataset.infoKey;
            const translation = translations[infoKey]?.[currentLang] || translations[infoKey]?.['en'];
            if (infoKey && translation) {
                showNotification(translation, 'info', 10000);
            }
        }
    });

    async function updateStatusAndModuleInfo() {
        try {
            const statusData = await handleApiCall('/api/get-full-status');
            if (statusData && statusData.status === 'success' && statusData.details) {
                const serviceStatus = statusData.details.service_status || 'stopped';
                isServiceRunning = serviceStatus.toLowerCase() === 'running';
                
                statusElements.serviceStatus.textContent = serviceStatus;
                statusElements.serviceStatus.className = `status-badge status-${serviceStatus.toLowerCase()}`;
                statusElements.servicePid.textContent = statusData.details.pid || 'N/A';
                statusElements.runningTime.textContent = statusData.details.uptime || 'N/A';
                statusElements.cpuUsage.textContent = statusData.details.service_cpu_usage || 'N/A';
                statusElements.systemCpuLoad.textContent = statusData.details.system_cpu_usage || 'N/A';
                statusElements.ramUsage.textContent = statusData.details.ram_usage || 'N/A';
                
                document.getElementById('service-banner').src = isServiceRunning ? '/img/running.webp' : '/img/stopped.webp';
            }
        } catch (e) {
            isServiceRunning = false;
            console.error("Error fetching main status:", e);
        }

        try {
            const logData = await handleApiCall('/api/get-log-info');
            if (logData && logData.status === 'success') {
                const log = logData.log_content || "";
                moduleInfoElements.moduleName.textContent = (log.match(/• Name\s+:\s+(.*)/i) || [])[1] || 'N/A';
                moduleInfoElements.moduleVersion.textContent = (log.match(/• Version\s+:\s+(.*)/i) || [])[1] || 'N/A';
                moduleInfoElements.moduleDeveloper.textContent = (log.match(/• Developer\s+:\s+(.*)/i) || [])[1] || 'N/A';
                moduleInfoElements.moduleStatus.textContent = (log.match(/• Status\s+:\s+(.*)/i) || [])[1] || 'N/A';
                moduleInfoElements.modulePlugins.textContent = (log.match(/• Plugins-installed:\s*(.*)/i) || [])[1] || 'N/A';
                moduleInfoElements.moduleCredits.textContent = (log.match(/• Credits\s+:\s+(.*)/i) || [])[1] || 'N/A';
                const profileLines = log.split('\n').filter(line => line.includes('Activated') || line.includes('Deactivated'));
                if (profileLines.length > 0) {
                    const lastProfile = profileLines[profileLines.length - 1];
                    statusElements.currentProfileMode.textContent = lastProfile.includes('Activated') ? 'Performance' : 'Balanced';
                } else {
                    statusElements.currentProfileMode.textContent = 'Unknown';
                }
            }
        } catch (e) {
            console.error("Error fetching log info:", e);
        }
        
        updateDependentControls();
    }
    
    function renderOsTunningTab() {
        const osTunningNavItem = document.getElementById('os-tunning-nav-item');
        const miuiSettings = document.getElementById('miui-hyperos-settings');
        const xosSettings = document.getElementById('xos-settings');
        const funtouchosSettings = document.getElementById('funtouchos-settings');
        const colorosSettings = document.getElementById('coloros-settings');
        const unsupportedSettings = document.getElementById('unsupported-os-settings');

        document.querySelectorAll('.os-specific-settings').forEach(el => el.style.display = 'none');
        osTunningNavItem.style.display = 'none';

        let hasOsSpecificSettings = false;
        if (currentOS === 'MIUI' || currentOS === 'HyperOS') {
            miuiSettings.style.display = 'block';
            hasOsSpecificSettings = true;
        } else if (currentOS === 'XOS') {
            xosSettings.style.display = 'block';
            hasOsSpecificSettings = true;
        } else if (currentOS === 'FuntouchOS') {
            funtouchosSettings.style.display = 'block';
            hasOsSpecificSettings = true;
        } else if (currentOS === 'ColorOS') {
            colorosSettings.style.display = 'block';
            hasOsSpecificSettings = true;
        } else if (currentOS !== 'Unknown' && currentOS !== 'Motorola') {
            unsupportedSettings.style.display = 'block';
            hasOsSpecificSettings = true;
        }

        if (hasOsSpecificSettings) {
            osTunningNavItem.style.display = 'list-item';
        }
    }

    async function updateDeviceInfo() {
        try {
            const response = await handleApiCall('/api/get-device-info');
            const deviceData = response.data;
            deviceInfoElements.deviceBrand.textContent = deviceData.brand || 'N/A';
            deviceInfoElements.deviceName.textContent = deviceData.model || 'N/A';
            deviceInfoElements.deviceArchitecture.textContent = deviceData.architecture || 'N/A';
            const androidVersion = deviceData.android_version || 'N/A';
            const sdkVersion = deviceData.sdk_version || 'N/A';
            currentOS = deviceData.os_name || 'Unknown';
            deviceInfoElements.deviceOsName.textContent = currentOS;
            deviceInfoElements.deviceAndroidVersion.textContent = androidVersion;
            deviceInfoElements.deviceSdkVersion.textContent = sdkVersion;
            deviceInfoElements.deviceKernelVersion.textContent = deviceData.kernel_version || 'N/A';
            
            const sdkVersionInt = parseInt(sdkVersion, 10);
            document.getElementById('gapps-limiter-item').classList.toggle('disabled', sdkVersionInt < 33);
            allowCompactionContainer.classList.toggle('disabled', sdkVersionInt < 33);

            const dynamicSwapItem = document.getElementById('dynamic-swap-item');
            if (dynamicSwapItem) {
                dynamicSwapItem.classList.toggle('disabled', sdkVersionInt < 34);
            }
            
            renderOsTunningTab();
        } catch(e) { console.error("Error fetching device info:", e); }
    }

    refreshButton.addEventListener('click', (e) => {
        const btn = e.currentTarget;
        btn.classList.add('loading');
        btn.disabled = true;
        shutdownLoader.style.display = 'flex';
        initialize(true).finally(() => {
            setTimeout(() => {
                btn.classList.remove('loading');
                btn.disabled = false;
                shutdownLoader.style.display = 'none';
                showNotification(translations['status_refreshed']?.[currentLang] || 'Status refreshed', 'success', 2000);
            }, 500);
        });
    });

    exitButton.addEventListener('click', async (e) => {
        if (isServiceRunning && settingsChanged) {
            exitConfirmModal.style.display = 'flex';
            return;
        }
        
        const shutdownText = translations['shutting_down']?.[currentLang] || 'Shutting down server...';
        shutdownLoader.querySelector('p').textContent = shutdownText;
        shutdownLoader.style.display = 'flex';
        try {
            await handleApiCall('/api/exit');
        } catch (error) {
            console.error("Shutdown failed:", error);
            shutdownLoader.style.display = 'none';
            showNotification(translations['shutdown_failed']?.[currentLang] || 'Failed to shut down server.', 'error');
        }
    });

    exitConfirmContinueBtn.addEventListener('click', async () => {
        exitConfirmModal.style.display = 'none';
        await exitButton.click();
    });

    exitConfirmReloadBtn.addEventListener('click', async () => {
        exitConfirmModal.style.display = 'none';
        const reloadBtn = document.querySelector('.action-button[data-command="reload-settings"]');
        await handleApiCall('/api/reload-settings', {}, reloadBtn);
        await exitButton.click();
    });

    document.addEventListener('click', e => {
        if (e.target === exitConfirmModal || e.target === launcherWarningModal) {
            exitConfirmModal.style.display = 'none';
            launcherWarningModal.style.display = 'none';
        }
    });

    actionButtons.forEach(button => {
        button.addEventListener('click', async (e) => {
            const command = button.dataset.command;
            if (!command) return;
            const url = `/api/${command}`;
            const btn = e.currentTarget;

            if (command === 'install') {
                try {
                    await handleApiCall(url, {}, btn);
                    showNotification(translations['installation_successful'][currentLang] || 'Installation successful!', 'success');
                    await updateStatusAndModuleInfo();
                } catch (error) {
                    let reason = error.message;
                    if (error.data && error.data.failed_script) {
                        reason = `${(translations['reason'][currentLang] || 'Reason')}: ${error.data.failed_script}, Exit Code: ${error.data.exit_code}`;
                    }
                    showNotification(`${translations['installation_failed'][currentLang] || 'Installation failed'}.<br>${reason}`, 'error', 8000);
                }
            } else if (command === 'reload-settings') {
                const reloadText = translations['reloading']?.[currentLang] || 'Reloading...';
                shutdownLoader.querySelector('p').textContent = reloadText;
                shutdownLoader.style.display = 'flex';
                try {
                    await handleApiCall(url, {}, btn);
                    settingsChanged = false;
                    setTimeout(() => location.reload(), 1000); 
                } catch (error) {
                    shutdownLoader.style.display = 'none';
                    showNotification(error.message, 'error');
                }
            } else {
                try {
                    await handleApiCall(url, {}, btn);
                     showNotification(translations['operation_successful'][currentLang] || 'Operation Successful!', 'success', 2500);
                    if (command === 'uninstall') {
                        await updateStatusAndModuleInfo();
                    }
                } catch (error) {
                    showNotification(error.message, 'error');
                }
            }
        });
    });

    function setupOldStyleToggles() {
        const toggles = [
            { el: document.getElementById('doze-toggle'), on: 'doze', off: 'undoze' },
            { el: document.getElementById('device-config-opt-toggle'), on: 'device-config_opt', off: 'delete_device-config_opt' },
            { el: document.getElementById('silent-log-toggle'), on: 'silent_log', off: 'silent_log-disable' }
        ];
        toggles.forEach(t => {
            if (t.el) {
                t.el.addEventListener('change', e => {
                    const command = e.target.checked ? t.on : t.off;
                    handleApiCall(`/api/${command}`, {}, e.currentTarget).catch(() => {
                        e.target.checked = !e.target.checked;
                    });
                });
            }
        });
    }

    function setupActionBars() {
        const driverApplyButton = document.getElementById('driver-apply-button');
        const touchApplyButton = document.getElementById('touch-apply-button');
        const swappyApplyButton = document.getElementById('swappy-apply-button');
        let selectedSwappyParam = 'stop';
        
        setupBarSelection(document.getElementById('driver-selection-bar'), (button) => {
            document.getElementById('driver-selected-value').textContent = button.textContent;
            if (driverApplyButton) driverApplyButton.dataset.param = button.dataset.param;
        });
        if(driverApplyButton) driverApplyButton.addEventListener('click', e => {
            const param = e.currentTarget.dataset.param || 'reset';
            handleApiCall(`/api/driver?type=${param}`, {}, e.currentTarget).catch(err => showNotification(err.message, 'error'));
        });

        setupBarSelection(document.getElementById('touch-selection-bar'), (button) => {
            document.getElementById('touch-selected-value').textContent = button.textContent;
            if (touchApplyButton) touchApplyButton.dataset.param = button.dataset.param;
        });
        if(touchApplyButton) touchApplyButton.addEventListener('click', e => {
            const param = e.currentTarget.dataset.param || 'reset';
            handleApiCall(`/api/touch?level=${param}`, {}, e.currentTarget).catch(err => showNotification(err.message, 'error'));
        });

        setupBarSelection(document.getElementById('swappy-selection-bar'), (button) => {
            selectedSwappyParam = button.dataset.param;
            document.getElementById('swappy-selected-value').textContent = button.textContent;
        });
        swappyApplyButton.addEventListener('click', async (e) => {
            try {
                await handleApiCall(`/api/swappy-delta?type=${selectedSwappyParam}`, {}, e.currentTarget);
                await updateStatusAndModuleInfo();
            } catch(err) {
                showNotification(err.message, 'error');
            }
        });
    }

    function updateDependentControls() {
        const ramManagerOn = document.getElementById('ram_manager-toggle')?.checked;
        const bypassRefreshRateOn = document.getElementById('bypass_dynamic_refresh_rate-toggle')?.checked;
        const useTrimMemoryOn = document.getElementById('use_trim_memory-toggle')?.checked;
        const parallelExecOn = document.getElementById('pararel_execution_conf-toggle')?.checked;
        const gamePreloadingOn = document.querySelector('[data-key="game_preloading"]')?.checked;
        const dynamicSwapOn = document.querySelector('[data-key="dynamic_swap_enabled"]')?.checked;
        const sdkVersion = parseInt(deviceInfoElements.deviceSdkVersion.textContent, 10) || 0;
        
        document.querySelectorAll('.ram-dependent').forEach(el => el.classList.toggle('disabled', !ramManagerOn));
        document.querySelector('[data-key="trim_memory_level"]')?.closest('.setting-item').classList.toggle('disabled', !ramManagerOn || !useTrimMemoryOn);
        document.querySelector('[data-key="device_refresh_rate"]')?.closest('.setting-item').classList.toggle('disabled', !bypassRefreshRateOn);
        document.querySelector('[data-key="device-group"]')?.closest('.setting-item').classList.toggle('disabled', !bypassRefreshRateOn);
        document.querySelector('[data-key="Preload_size_limit"]')?.closest('.setting-item').classList.toggle('disabled', !gamePreloadingOn);
        document.querySelector('[data-key="swap_threshold_adjust_perc"]')?.closest('.setting-item').classList.toggle('disabled', !dynamicSwapOn);
        
        document.querySelectorAll('[data-key^="max_pararel_thread"], [data-key^="pararel_dir_"]').forEach(control => {
            control.closest('.setting-item').classList.toggle('disabled', !parallelExecOn);
        });

        allowCompactionContainer.classList.toggle('disabled', !ramManagerOn || sdkVersion < 33);
    }

    async function loadModuleScripts() {
        try {
            const data = await handleApiCall('/api/get-module-scripts');
            if (data && data.status === 'success' && data.scripts) {
                moduleScripts = data.scripts;
                const datalist = document.getElementById('module-scripts-list');
                datalist.innerHTML = '';
                data.scripts.forEach(scriptName => {
                    const option = document.createElement('option');
                    option.value = scriptName;
                    datalist.appendChild(option);
                });
            }
        } catch (e) { console.error("Error loading module scripts:", e); }
    }

    async function loadAllSettings() {
        try {
            const data = await handleApiCall('/api/get-all-settings');
            if (data && data.status === 'success') {
                const settings = data.settings;
                for (const key in settings) {
                    const value = settings[key];
                    const elements = document.querySelectorAll(`[data-key="${key}"]`);
                    if (elements.length === 0) continue;

                    elements.forEach(element => {
                        if (element.type === 'checkbox') {
                            const onValue = element.dataset.on || 'Y';
                            element.checked = (value.toLowerCase() === onValue.toLowerCase());
                        } else if (element.tagName === 'INPUT' && (element.type === 'text' || element.type === 'number')) {
                            element.value = value;
                            const slider = document.getElementById(`${key}-slider`);
                            if (slider) slider.value = value;
                        } else if (element.classList.contains('bar-selection')) {
                            const selectedValueEl = element.querySelector('.selected-value');
                            const option = element.querySelector(`[data-value="${value}"]`);
                            if (selectedValueEl) {
                                selectedValueEl.textContent = option ? option.textContent : value;
                            }
                        }
                    });
                }
                document.body.classList.toggle('lite-mode-active', settings.lite_mode === '1');
                
                const standbyVal = settings.standby === 'true';
                standbyToggle.checked = standbyVal;
                shutdownTimeItem.classList.toggle('disabled', standbyVal);
                if (settings.shutdowntime) {
                    document.getElementById('shutdowntime-input').value = settings.shutdowntime;
                    document.getElementById('shutdowntime-slider').value = settings.shutdowntime;
                }
                if (settings.warning_ram_perc) warningRamInput.value = settings.warning_ram_perc;
                if (settings.critical_ram_perc) criticalRamInput.value = settings.critical_ram_perc;
                if (settings.icon_quality) {
                    document.getElementById('icon_quality-input').value = settings.icon_quality;
                    document.getElementById('icon_quality-slider').value = settings.icon_quality;
                }
                
                updateDependentControls();
            }
        } catch (e) { console.error("Error loading all settings:", e); }
    }

    document.querySelectorAll('[data-key]').forEach(element => {
        const file = element.dataset.file;
        const key = element.dataset.key;
        if (element.type === 'checkbox') {
            element.addEventListener('change', (e) => {
                const onValue = e.target.dataset.on || 'Y';
                const offValue = e.target.dataset.off || 'N';
                const value = e.target.checked ? onValue : offValue;
                saveSetting(file, key, value);
                updateDependentControls();
            });
        } else if (element.tagName === 'INPUT' && (element.type === 'text' || element.type === 'number')) {
             let debounceTimer;
             element.addEventListener('input', (e) => {
                clearTimeout(debounceTimer);
                const slider = document.getElementById(`${key}-slider`);
                if (slider) slider.value = e.target.value;
                 if(element.dataset.key !== "warning_ram_perc" && element.dataset.key !== "critical_ram_perc") {
                    debounceTimer = setTimeout(() => {
                        saveSetting(file, key, e.target.value);
                    }, 800);
                 }
            });
        } else if (element.classList.contains('bar-selection')) {
            setupBarSelection(element, (button) => {
                const value = button.dataset.value;
                const selectedValueEl = element.querySelector('.selected-value');
                selectedValueEl.textContent = button.textContent;
                saveSetting(file, key, value);
            });
        }
    });
    
    document.querySelectorAll('.range-slider').forEach(slider => {
        const input = slider.nextElementSibling || document.getElementById(slider.id.replace('-slider', '-input'));
        if (input && input.classList.contains('range-value-input')) {
            slider.addEventListener('input', (e) => {
                input.value = e.target.value;
                input.dispatchEvent(new Event('input', { bubbles:true, cancelable:true }));
            });
        }
    });
    
    async function initialize(isRefresh = false) {
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const initialThemeIsLight = savedTheme ? savedTheme === 'light' : !prefersDark;
        themeToggle.checked = initialThemeIsLight;
        applyTheme(initialThemeIsLight);

        if (!isRefresh) {
            const savedLang = localStorage.getItem('language');
            setLanguage(savedLang || 'en');
        }
        
        try {
            await Promise.all([
                updateDeviceInfo(),
                updateStatusAndModuleInfo(),
                loadModuleScripts(),
                loadAllSettings()
            ]);
        } catch (error) {
            console.error("Initialization failed:", error);
        }
        
        if (!isRefresh) {
            setupLanguageSelection();
            setupCpuTrace();
            setupWebUISettings();
            setupRamThresholds();
            setupOldStyleToggles();
            setupActionBars();
            setInterval(updateStatusAndModuleInfo, 30000);
        }
    }

    initialize();
});